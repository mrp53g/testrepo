package view;

import javax.faces.component.UIComponent;

import oracle.adf.view.rich.component.rich.nav.RichButton;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.render.ClientEvent;

public class TestBean {
    public TestBean() {
        super();
    }
    
    public void handleReturnServerEvent(ClientEvent event){
        //RichButton comp = (RichButton)event.getComponent();
        Object returnLineIds = event.getParameters().get("returnLines");
        if(returnLineIds != null){
            System.out.println("Return from template value:" + returnLineIds);
            AdfFacesContext.getCurrentInstance().getPageFlowScope().put("returnLineIds", returnLineIds);
        }
        
    }
    
    public String back(){
        System.out.println("Inside action method");
        return "back";
    }
}
